from django.contrib import admin
from .models import (
    Church,
    ChurchFollow,
    BookableService,
    ServiceImage,
    Availability,
    Booking,
    Post,
    PostReport,
    ChurchVerificationRequest,
    ChurchVerificationDocument,
    Notification,
)


@admin.register(Church)
class ChurchAdmin(admin.ModelAdmin):
    list_display = (
        'name', 'city', 'state', 'owner', 'is_verified', 'is_active', 'created_at',
    )
    search_fields = (
        'name', 'city', 'state', 'email', 'owner__username',
    )
    list_filter = (
        'is_verified', 'is_active', 'denomination', 'size', 'city', 'created_at',
    )
    readonly_fields = ('created_at', 'updated_at')
    prepopulated_fields = { 'slug': ('name',) }
    autocomplete_fields = ('owner',)


class ServiceImageInline(admin.TabularInline):
    model = ServiceImage
    extra = 1


@admin.register(BookableService)
class BookableServiceAdmin(admin.ModelAdmin):
    list_display = (
        'name', 'church', 'is_active', 'is_free', 'price', 'duration', 'created_at',
    )
    search_fields = ('name', 'church__name')
    list_filter = ('is_active', 'is_free', 'duration', 'church', 'created_at')
    autocomplete_fields = ('church',)
    inlines = [ServiceImageInline]


@admin.register(ServiceImage)
class ServiceImageAdmin(admin.ModelAdmin):
    list_display = ('service', 'order', 'is_primary', 'caption')
    list_filter = ('is_primary', 'service')
    search_fields = ('service__name', 'caption')
    autocomplete_fields = ('service',)


@admin.register(Availability)
class AvailabilityAdmin(admin.ModelAdmin):
    list_display = ('church', 'date', 'type', 'is_closed')
    list_filter = ('type', 'is_closed', 'date', 'church')
    search_fields = ('church__name', 'reason', 'notes')
    autocomplete_fields = ('church',)


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = (
        'code', 'service', 'church', 'user', 'date', 'status', 'created_at',
    )
    list_filter = ('status', 'date', 'church', 'service', 'created_at')
    search_fields = ('code', 'service__name', 'church__name', 'user__username', 'user__email')
    autocomplete_fields = ('service', 'church', 'user')
    list_select_related = ('service', 'church', 'user')


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('church', 'short_content', 'is_active', 'created_at')
    list_filter = ('is_active', 'church', 'created_at')
    search_fields = ('church__name', 'content')
    autocomplete_fields = ('church',)

    def short_content(self, obj):
        return (obj.content or '')[:60]
    short_content.short_description = 'Content'


@admin.register(PostReport)
class PostReportAdmin(admin.ModelAdmin):
    list_display = ('user', 'post', 'reason', 'status', 'created_at')
    list_filter = ('status', 'reason', 'created_at')
    search_fields = ('user__username', 'user__email', 'post__content', 'description')
    autocomplete_fields = ('user', 'post', 'reviewed_by')
    readonly_fields = ('created_at',)
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user', 'post', 'post__church')


@admin.register(ChurchVerificationRequest)
class ChurchVerificationRequestAdmin(admin.ModelAdmin):
    list_display = ('church', 'status', 'submitted_by', 'reviewed_by', 'created_at')
    list_filter = ('status', 'church', 'created_at')
    search_fields = ('church__name', 'submitted_by__username', 'submitted_by__email', 'notes')
    autocomplete_fields = ('church', 'submitted_by', 'reviewed_by')
    date_hierarchy = 'created_at'


@admin.register(ChurchVerificationDocument)
class ChurchVerificationDocumentAdmin(admin.ModelAdmin):
    list_display = ('request', 'title', 'file', 'uploaded_at')
    search_fields = ('title', 'file')
    autocomplete_fields = ('request',)


@admin.register(ChurchFollow)
class ChurchFollowAdmin(admin.ModelAdmin):
    list_display = ('user', 'church', 'followed_at')
    list_filter = ('church', 'followed_at')
    search_fields = ('user__username', 'user__email', 'church__name')
    autocomplete_fields = ('user', 'church')


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('user', 'title', 'notification_type', 'priority', 'is_read', 'created_at')
    list_filter = ('notification_type', 'priority', 'is_read', 'created_at')
    search_fields = ('user__username', 'user__email', 'title', 'message')
    autocomplete_fields = ('user', 'booking', 'church')
    list_select_related = ('user', 'booking', 'church')
    readonly_fields = ('created_at', 'updated_at', 'read_at')
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user', 'booking', 'church')
