# Django templatetags package for core app
