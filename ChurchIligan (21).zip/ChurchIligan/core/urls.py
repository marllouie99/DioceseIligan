from django.urls import path
from . import views
from . import api_views

app_name = 'core'

urlpatterns = [
    path('', views.home, name='home'),
    path('discover/', views.discover, name='discover'),
    path('create-church/', views.create_church, name='create_church'),
    path('church/<slug:slug>/', views.church_detail, name='church_detail'),
    path('manage-church/', views.manage_church, name='manage_church'),
    path('follow-church/<int:church_id>/', views.follow_church, name='follow_church'),
    path('unfollow-church/<int:church_id>/', views.unfollow_church, name='unfollow_church'),
    path('events/', views.events, name='events'),
    path('appointments/', views.appointments, name='appointments'),
    path('following/', views.following, name='following'),
    path('manage/', views.manage, name='manage'),
    path('settings/', views.settings_page, name='settings_page'),
    # Super Admin
    path('super-admin/', views.super_admin_dashboard, name='super_admin_dashboard'),
    path('super-admin/profile/', views.super_admin_profile, name='super_admin_profile'),
    path('super-admin/toggle-mode/', views.toggle_super_admin_mode, name='toggle_super_admin_mode'),
    path('super-admin/user-activities/', views.super_admin_user_activities, name='super_admin_user_activities'),
    
    # Media updates (AJAX)
    path('settings/update-logo/', views.update_church_logo, name='update_church_logo'),
    path('settings/update-cover/', views.update_church_cover, name='update_church_cover'),
    # Verification (owner)
    path('verification/request/', views.request_verification, name='request_verification'),
    # Verification (super-admin)
    path('super-admin/verifications/', views.super_admin_verifications, name='super_admin_verifications'),
    path('super-admin/verifications/<int:request_id>/approve/', views.approve_verification, name='approve_verification'),
    path('super-admin/verifications/<int:request_id>/reject/', views.reject_verification, name='reject_verification'),
    
    # Decline Reasons Management (owner)
    path('settings/decline-reasons/create/', views.create_decline_reason, name='create_decline_reason'),
    path('settings/decline-reasons/<int:reason_id>/delete/', views.delete_decline_reason, name='delete_decline_reason'),
    path('settings/decline-reasons/<int:reason_id>/toggle/', views.toggle_decline_reason, name='toggle_decline_reason'),
    
    # Bookable Services Management
    path('manage-services/', views.manage_services, name='manage_services'),
    path('create-service/', views.create_service, name='create_service'),
    path('edit-service/<int:service_id>/', views.edit_service, name='edit_service'),
    path('delete-service/<int:service_id>/', views.delete_service, name='delete_service'),
    path('manage-service-images/<int:service_id>/', views.manage_service_images, name='manage_service_images'),
    path('delete-service-image/<int:image_id>/', views.delete_service_image, name='delete_service_image'),
    path('service-gallery/<int:service_id>/', views.service_gallery, name='service_gallery'),
    path('book-service/<int:service_id>/', views.book_service, name='book_service'),
    path('manage-booking/<int:booking_id>/', views.manage_booking, name='manage_booking'),
    path('booking-invoice/<int:booking_id>/', views.booking_invoice, name='booking_invoice'),
    path('api/test/', views.api_test, name='api_test'),
    path('api/bookings/create/', views.create_booking_api, name='create_booking_api'),
    path('api/service/<int:service_id>/', views.api_get_service, name='api_get_service'),
    path('api/service-images/<int:service_id>/', views.api_service_images, name='api_service_images'),
    path('api/church/<int:church_id>/availability/', views.api_get_church_availability, name='api_get_church_availability'),
    
    # Availability Management
    path('manage-availability/', views.manage_availability, name='manage_availability'),
    path('create-availability/', views.create_availability, name='create_availability'),
    path('edit-availability/<int:availability_id>/', views.edit_availability, name='edit_availability'),
    path('delete-availability/<int:availability_id>/', views.delete_availability, name='delete_availability'),
    path('bulk-availability/', views.bulk_availability, name='bulk_availability'),
    
    # Posts
    path('create-post/<slug:church_slug>/', views.create_post, name='create_post'),
    path('dashboard/create-post/', views.dashboard_create_post, name='dashboard_create_post'),
    path('edit-post/<int:post_id>/', views.edit_post, name='edit_post'),
    path('posts/<int:post_id>/data/', views.get_post_data, name='get_post_data'),
    path('posts/<int:post_id>/update/', views.update_post, name='update_post'),
    path('posts/<int:post_id>/report/', views.report_post, name='report_post'),
    
    # Post Interactions (AJAX)
    path('posts/<int:post_id>/like/', views.toggle_post_like, name='toggle_post_like'),
    path('posts/<int:post_id>/bookmark/', views.toggle_post_bookmark, name='toggle_post_bookmark'),
    path('posts/<int:post_id>/comment/', views.add_post_comment, name='add_post_comment'),
    path('posts/<int:post_id>/comments/', views.get_post_comments, name='get_post_comments'),
    path('posts/<int:post_id>/share/', views.share_post, name='share_post'),
    path('posts/<int:post_id>/view/', views.track_post_view, name='track_post_view'),
    
    # Service Reviews
    path('service/<int:service_id>/review/', views.create_service_review, name='create_service_review'),
    path('service/<int:service_id>/reviews/', views.service_reviews, name='service_reviews'),
    path('review/<int:review_id>/helpful/', views.toggle_review_helpful, name='toggle_review_helpful'),
    
    # Notifications
    path('notifications/', views.notifications, name='notifications'),
    path('notifications/dropdown/', views.notification_dropdown, name='notification_dropdown'),
    path('notifications/<int:notification_id>/mark-read/', views.mark_notification_read, name='mark_notification_read'),
    path('notifications/mark-all-read/', views.mark_all_notifications_read, name='mark_all_notifications_read'),
    path('notifications/count/', views.notification_count, name='notification_count'),
    
    # API endpoints
    path('api/service/<int:service_id>/images/', views.service_images_api, name='service_images_api'),
    
    # Follower Management API endpoints
    path('api/followers/', api_views.followers_list_api, name='followers_list_api'),
    path('api/followers/<int:user_id>/stats/', api_views.follower_stats_api, name='follower_stats_api'),
    path('api/followers/<int:user_id>/activity/<str:activity_type>/', api_views.follower_activity_api, name='follower_activity_api'),
    path('api/interactions/log/', api_views.log_interaction_api, name='log_interaction_api'),
]
