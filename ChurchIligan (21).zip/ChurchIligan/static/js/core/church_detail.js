document.addEventListener('DOMContentLoaded', function() {
  // Handle follow/unfollow button
  const followBtn = document.querySelector('.follow-btn');

  if (followBtn) {
    followBtn.addEventListener('click', function() {
      const churchId = this.dataset.churchId;
      const action = this.dataset.action;
      const url = action === 'follow' ? window.djangoUrls.followChurch.replace('0', churchId) : window.djangoUrls.unfollowChurch.replace('0', churchId);

      const originalText = this.innerHTML;
      this.innerHTML = '<svg class="animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg> Following...';
      this.disabled = true;

      fetch(url, {
        method: 'POST',
        headers: {
          'X-CSRFToken': window.csrfToken || document.querySelector('[name=csrfmiddlewaretoken]').value,
          'Content-Type': 'application/json',
        },
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          if (data.action === 'followed') {
            this.dataset.action = 'unfollow';
            this.innerHTML = `
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
                <circle cx="9" cy="7" r="4"/>
                <path d="M23 21v-2a4 4 0 00-3-3.87"/>
                <path d="M16 3.13a4 4 0 010 7.75"/>
              </svg>
              Following
            `;
            this.classList.add('following');
          } else {
            this.dataset.action = 'follow';
            this.innerHTML = `
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
                <circle cx="9" cy="7" r="4"/>
                <path d="M23 21v-2a4 4 0 00-3-3.87"/>
                <path d="M16 3.13a4 4 0 010 7.75"/>
              </svg>
              Follow
            `;
            this.classList.remove('following');
          }

          const followerCount = document.querySelector('.stat-number');
          if (followerCount) {
            followerCount.textContent = data.follower_count;
          }

          showNotification(data.message, 'success');
        } else {
          showNotification(data.message, 'error');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        showNotification('An error occurred. Please try again.', 'error');
      })
      .finally(() => {
        this.disabled = false;
      });
    });
  }

  // Tabs behavior
  const tabButtons = document.querySelectorAll('.tab-btn');
  const panels = document.querySelectorAll('.tab-panel');
  function activateTab(name) {
    tabButtons.forEach(b => b.classList.toggle('active', b.dataset.tab === name));
    panels.forEach(p => p.classList.toggle('active', p.id === name));
  }
  tabButtons.forEach(b => b.addEventListener('click', () => activateTab(b.dataset.tab)));
  
  // Check for hash in URL and activate corresponding tab
  function handleHashNavigation() {
    const hash = window.location.hash.substring(1); // Remove the # symbol
    if (hash && document.getElementById(hash)) {
      activateTab(hash);
    } else {
      activateTab('posts');
    }
  }
  
  // Initial tab activation
  handleHashNavigation();
  
  // Listen for hash changes (when user uses back/forward buttons)
  window.addEventListener('hashchange', handleHashNavigation);
});

// Modal functions
function showCreatePostModal() {
  document.getElementById('createPostModal').style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function hideCreatePostModal() {
  document.getElementById('createPostModal').style.display = 'none';
  document.body.style.overflow = 'auto';
  document.getElementById('createPostForm').reset();
}

// Close modal when clicking outside
window.onclick = function(event) {
  const modal = document.getElementById('createPostModal');
  if (event.target === modal) {
    hideCreatePostModal();
  }
}

// Removed legacy post menu handlers in favor of global delegated handler

// Filter functions
function filterPosts(filter) {
  const posts = document.querySelectorAll('.post-card');
  const filterTabs = document.querySelectorAll('.filter-tab');

  filterTabs.forEach(tab => {
    tab.classList.toggle('active', tab.dataset.filter === filter);
  });

  posts.forEach(post => {
    let show = true;
    switch(filter) {
      case 'recent':
        show = true;
        break;
      case 'with-images':
        show = post.querySelector('.post-image') !== null;
        break;
      case 'text-only':
        show = post.querySelector('.post-image') === null;
        break;
      case 'all':
      default:
        show = true;
        break;
    }
    post.style.display = show ? 'block' : 'none';
  });
}

function sortPosts(sortBy) {
  const postsContainer = document.querySelector('.posts-feed');
  const posts = Array.from(document.querySelectorAll('.post-card'));

  posts.sort((a, b) => {
    if (sortBy === 'oldest') {
      return 1;
    } else {
      return -1;
    }
  });

  posts.forEach(post => postsContainer.appendChild(post));
}

// Add event listeners for filter tabs
document.addEventListener('DOMContentLoaded', function() {
  const filterTabs = document.querySelectorAll('.filter-tab');
  filterTabs.forEach(tab => {
    tab.addEventListener('click', function() {
      filterPosts(this.dataset.filter);
    });
  });
});

function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => {
    notification.remove();
  }, 3000);
}

// Church detail image preview functionality
document.addEventListener('DOMContentLoaded', () => {
  const imageInput = document.getElementById('post-image');

  if (imageInput) {
    imageInput.addEventListener('change', (e) => {
      const file = e.target.files[0];

      if (file && file.type.startsWith('image/')) {
        if (file.size > 10 * 1024 * 1024) {
          alert('Image size must be less than 10MB.');
          e.target.value = '';
          return;
        }

        const reader = new FileReader();
        reader.onload = (event) => {
          const preview = document.getElementById('imagePreview');
          const previewImg = document.getElementById('previewImg');

          if (preview && previewImg) {
            previewImg.src = event.target.result;
            preview.style.display = 'block';
          }
        };
        reader.readAsDataURL(file);
      }
    });
  }
});

function removeImagePreview() {
  const preview = document.getElementById('imagePreview');
  const imageInput = document.getElementById('post-image');

  if (preview) {
    preview.style.display = 'none';
  }

  if (imageInput) {
    imageInput.value = '';
  }
}



