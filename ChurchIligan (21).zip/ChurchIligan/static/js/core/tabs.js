/**
 * Tab Management Module
 * @module Tabs
 */

class TabManager {
  constructor(config = {}) {
    this.config = {
      defaultTab: 'appointments',
      ...config
    };
  }

  /**
   * Initialize tab functionality
   */
  init() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanels = document.querySelectorAll('.tab-panel');
    
    if (!tabButtons.length || !tabPanels.length) return;
    
    // Get tab from URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const tabFromUrl = urlParams.get('tab');
    const activeTab = tabFromUrl || this.config.defaultTab;
    
    // Set initial active tab
    this.setActiveTab(activeTab, tabButtons, tabPanels);
    
    // Initialize sub-tabs
    this.initSubTabs();
    
    // Use event delegation for better performance and reliable targeting
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('.tab-btn');
      if (!btn) return;
      e.preventDefault();
      const targetTab = btn.getAttribute('data-tab');
      if (!targetTab) return;
      // Avoid redundant work if already active
      if (btn.classList.contains('active')) return;
      this.setActiveTab(targetTab, tabButtons, tabPanels);
      this.updateURL(targetTab);
    });

    // Keyboard support for accessibility
    document.addEventListener('keydown', (e) => {
      const btn = e.target.closest('.tab-btn');
      if (!btn) return;
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const targetTab = btn.getAttribute('data-tab');
        if (!targetTab) return;
        if (btn.classList.contains('active')) return;
        this.setActiveTab(targetTab, tabButtons, tabPanels);
        this.updateURL(targetTab);
      }
    });
  }

  /**
   * Initialize sub-tab functionality
   */
  initSubTabs() {
    // Handle sub-tab clicks
    document.addEventListener('click', (e) => {
      const subTabBtn = e.target.closest('.sub-tab-btn');
      if (!subTabBtn) return;
      e.preventDefault();
      
      const targetSubTab = subTabBtn.getAttribute('data-subtab');
      if (!targetSubTab) return;
      
      // Avoid redundant work if already active
      if (subTabBtn.classList.contains('active')) return;
      
      this.setActiveSubTab(targetSubTab);
    });

    // Keyboard support for sub-tabs
    document.addEventListener('keydown', (e) => {
      const subTabBtn = e.target.closest('.sub-tab-btn');
      if (!subTabBtn) return;
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const targetSubTab = subTabBtn.getAttribute('data-subtab');
        if (!targetSubTab) return;
        if (subTabBtn.classList.contains('active')) return;
        this.setActiveSubTab(targetSubTab);
      }
    });
  }

  /**
   * Set active sub-tab
   * @param {string} targetSubTab - Target sub-tab name
   */
  setActiveSubTab(targetSubTab) {
    const subTabButtons = document.querySelectorAll('.sub-tab-btn');
    const subTabPanels = document.querySelectorAll('.sub-tab-panel');
    
    // Remove active class from all sub-tab buttons and panels
    subTabButtons.forEach(btn => {
      btn.classList.remove('active');
      btn.setAttribute('aria-selected', 'false');
    });
    subTabPanels.forEach(panel => {
      panel.classList.remove('active');
      panel.setAttribute('aria-hidden', 'true');
    });
    
    // Add active class to target sub-tab button and panel
    const activeSubTabButton = document.querySelector(`[data-subtab="${targetSubTab}"]`);
    const activeSubTabPanel = document.getElementById(`content-${targetSubTab}`);
    
    if (activeSubTabButton) {
      activeSubTabButton.classList.add('active');
      activeSubTabButton.setAttribute('aria-selected', 'true');
    }
    if (activeSubTabPanel) {
      activeSubTabPanel.classList.add('active');
      activeSubTabPanel.setAttribute('aria-hidden', 'false');
    }
  }

  /**
   * Set active tab
   * @param {string} targetTab - Target tab name
   * @param {NodeList} tabButtons - Tab button elements
   * @param {NodeList} tabPanels - Tab panel elements
   */
  setActiveTab(targetTab, tabButtons, tabPanels) {
    // Remove active class from all buttons and panels
    tabButtons.forEach(btn => {
      btn.classList.remove('active');
      btn.setAttribute('aria-selected', 'false');
    });
    tabPanels.forEach(panel => {
      panel.classList.remove('active');
      panel.setAttribute('aria-hidden', 'true');
    });
    
    // Add active class to target button and panel
    const activeButton = document.querySelector(`[data-tab="${targetTab}"]`);
    const activePanel = document.getElementById(targetTab);
    
    if (activeButton) {
      activeButton.classList.add('active');
      activeButton.setAttribute('aria-selected', 'true');
    }
    if (activePanel) {
      activePanel.classList.add('active');
      activePanel.setAttribute('aria-hidden', 'false');
    }
  }

  /**
   * Update URL with tab parameter
   * @param {string} targetTab - Target tab name
   */
  updateURL(targetTab) {
    const url = new URL(window.location);
    if (targetTab === this.config.defaultTab) {
      url.searchParams.delete('tab');
    } else {
      url.searchParams.set('tab', targetTab);
    }
    window.history.pushState({}, '', url);
  }
}

// Export for use in main application
window.TabManager = TabManager;
