/**
 * Navigation Module
 * @module NavigationModule
 * @description Handles navigation highlighting and active state management
 * @version 1.0.0
 */

class NavigationModule {
  constructor() {
    this.isInitialized = false;
    this.navLinks = [];
  }

  /**
   * Initialize navigation functionality
   * @returns {boolean} Success status
   */
  init() {
    try {
      if (this.isInitialized) {
        return true;
      }

      this.setupNavigation();
      this.isInitialized = true;
      return true;
    } catch (error) {
      window.Utils?.handleError(error, 'NavigationModule Initialization');
      return false;
    }
  }

  /**
   * Setup navigation highlighting
   * @private
   */
  setupNavigation() {
    const current = window.location.pathname;
    this.navLinks = document.querySelectorAll('.sidebar .nav a');
    
    this.navLinks.forEach(link => {
      try {
        const href = link.getAttribute('href');
        if (!href || href === '#') return;
        
        if (current.startsWith(href)) {
          link.classList.add('active');
        } else {
          link.classList.remove('active');
        }
      } catch (e) {
        }
    });
  }

  /**
   * Update active navigation item
   * @param {string} path - Path to highlight
   */
  updateActiveNav(path) {
    this.navLinks.forEach(link => {
      const href = link.getAttribute('href');
      if (!href || href === '#') return;
      
      if (path.startsWith(href)) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }

  /**
   * Get current active navigation item
   * @returns {Element|null} Active navigation element
   */
  getActiveNav() {
    return document.querySelector('.sidebar .nav a.active');
  }

  /**
   * Cleanup navigation module
   */
  destroy() {
    this.navLinks = [];
    this.isInitialized = false;
  }
}

// Export for use in main application
window.NavigationModule = NavigationModule;
