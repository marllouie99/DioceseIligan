(function(){
  const tabSignin = document.getElementById('tab-signin');
  const tabSignup = document.getElementById('tab-signup');
  const signinForm = document.getElementById('signin-form');
  const signupForm = document.getElementById('signup-form');
  const linkSignup = document.getElementById('link-signup');
  const linkSignin = document.getElementById('link-signin');
  const heading = document.getElementById('heading-title');

  function setActive(tab){
    if(!tabSignin || !tabSignup || !signinForm || !signupForm) return;
    if(tab === 'signup'){
      tabSignin.classList.remove('active');
      tabSignup.classList.add('active');
      signinForm.style.display = 'none';
      signupForm.style.display = 'block';
      if (heading) heading.textContent = 'Create your account';
      const first = signupForm.querySelector('input');
      if (first) first.focus();
    } else {
      tabSignin.classList.add('active');
      tabSignup.classList.remove('active');
      signinForm.style.display = 'block';
      signupForm.style.display = 'none';
      if (heading) heading.textContent = 'Welcome to ChurchConnect';
      const first = signinForm.querySelector('input');
      if (first) first.focus();
    }
  }

  if (tabSignin) tabSignin.addEventListener('click', function(){ setActive('signin'); });
  if (tabSignup) tabSignup.addEventListener('click', function(){ setActive('signup'); });
  if (linkSignup) linkSignup.addEventListener('click', function(e){ e.preventDefault(); setActive('signup'); });
  if (linkSignin) linkSignin.addEventListener('click', function(e){ e.preventDefault(); setActive('signin'); });

  // Password visibility toggles
  function setupPasswordToggles(){
    document.querySelectorAll('.password-toggle').forEach(function(btn){
      btn.addEventListener('click', function(){
        const container = btn.closest('.input');
        if(!container) return;
        const input = container.querySelector('input[type="password"], input[type="text"]');
        if(!input) return;
        if(input.type === 'password'){
          input.type = 'text';
          btn.textContent = '🙈';
        } else {
          input.type = 'password';
          btn.textContent = '👁';
        }
      });
    });
  }

  setupPasswordToggles();

})();
