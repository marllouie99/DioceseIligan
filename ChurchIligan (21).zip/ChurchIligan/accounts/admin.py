from django.contrib import admin
from .models import Profile


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = (
        'user_username', 'user_email', 'display_name', 'phone', 'date_of_birth', 'created_at',
    )
    search_fields = (
        'user__username', 'user__email', 'display_name', 'phone',
    )
    list_filter = ('date_of_birth', 'created_at')
    readonly_fields = ('created_at', 'updated_at')
    autocomplete_fields = ('user',)

    def user_username(self, obj):
        return obj.user.get_username()

    user_username.short_description = 'Username'

    def user_email(self, obj):
        return obj.user.email
